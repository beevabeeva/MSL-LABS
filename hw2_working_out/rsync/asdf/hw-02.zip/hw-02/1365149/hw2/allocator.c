// allocator.c
#include "allocator.h"
#include <stdio.h>
#include <unistd.h>
#include <stddef.h>
#include <string.h>

bool hasMallocedBefore = false;

int getNextPowerOfTwo(int number){
	number--;
	number |= number >> 1;
	number |= number >> 2;
	number |= number >> 4;
	number |= number >> 8;
	number |= number >> 16;
	number++;

	return(number);
}

struct block* createBlock(int sizer, struct block* startOfBlock){
	struct block* newBlock = startOfBlock;
	newBlock->size = sizer;
	newBlock->next = NULL;  //Fix here or set afterwards
	newBlock->free = true;
	newBlock->next = NULL;
	newBlock->buddy = NULL;
	newBlock->data = NULL;
	for(int i = 0; i < sizeof(newBlock->merge_buddy); i++){
		newBlock->merge_buddy[i] = NULL;
	}
	return newBlock;
}

/*void splitBlock(struct block* blockToSplit){
	struct block* newBlockOne = createBlock((blockToSplit->size)/2, blockToSplit);
	struct block* newBlockTwo = createBlock((blockToSplit->size)/2, (char*) blockToSplit + (blockToSplit->size/2));
	newBlockOne->data = newBlockOne + sizeof(struct block);		//Pointer to where the blocks metadata ends and where the actual data starts
	newBlockTwo->data = newBlockTwo + sizeof(struct block);
	newBlockOne->buddy = newBlockTwo;
	newBlockTwo->buddy = newBlockOne;
	newBlockTwo->next = blockToSplit->next;
	blockToSplit->next = newBlockOne;
	newBlockOne->next = newBlockTwo;
	newBlockOne->merge_buddy[0] = blockToSplit->buddy;
	newBlockTwo->merge_buddy[0] = blockToSplit->buddy;
}*/

void splitBlock(struct block* blockToSplit){
	struct block* newBlock = createBlock((blockToSplit->size)/2, (char*) blockToSplit + (blockToSplit->size/2));
	newBlock->data = (char*) newBlock + sizeof(struct block);
	newBlock->buddy = blockToSplit;
	newBlock->next = blockToSplit->next;
	newBlock->merge_buddy[0] = blockToSplit->buddy;
						    
	blockToSplit->size = blockToSplit->size/2;
	blockToSplit->buddy = newBlock;
	//blockToSplit->merge_buddy[0] = blockToSplit->next;
	blockToSplit->next = newBlock;
	printf("Just pointed to: %p\n", blockToSplit->next);
	printf("This pointer shouldn't change: %p\n", blockToSplit->next->next);
	
}

void findAndAllocateMemoryOnHeap(int size, struct block* wholeWindow){
	printf("Searching for size %d \n", size);
	bool foundCorrectSizeBlock = false;
	struct block* minBlockPointer = NULL;
	while(foundCorrectSizeBlock == false){
		struct block* iterator = head;
		minBlockPointer = head;
		while(iterator->next != NULL){
			if(iterator->size == size){
				//printf("Current iterator size is: %d \n", iterator->size);
				minBlockPointer = iterator;
				foundCorrectSizeBlock = true;
				break;
			}
			else if((iterator->size < minBlockPointer->size) && (iterator->size > size)){
				//printf("Reallocating minBlockPointer\n");
				minBlockPointer = iterator;
			}
			//print_list();
			iterator = iterator->next;
		}
		if(foundCorrectSizeBlock == false){
			printf("About to split block of size %d, at address %p\n", minBlockPointer->size, minBlockPointer);
			print_list();				    
			splitBlock(minBlockPointer);
			//printf("After split");
			//print_list();
		}
		else{
			printf("Have found correct block size\n");
			printf("Block found size is: %d\n", minBlockPointer->size);
			printf("Block at memory: %p\n", minBlockPointer);
		}
	}
	minBlockPointer->free = false;
}

/** Allocate a block of at least the requested size **/
void* custom_malloc(size_t size) {
    // TODO
	struct block* findBlock = head;
	if((size == 0) || (size > MAX_SIZE)){
		return(NULL);
	}
	else{
		struct block* wholeWindow = NULL;
		int sizePlusMeta = size + sizeof(struct block);
		int sizePlusMetaNextPowerOfTwo = getNextPowerOfTwo(sizePlusMeta);
		printf("\nWe want to find a block of size %d \n", sizePlusMetaNextPowerOfTwo);
		if(!hasMallocedBefore){
			wholeWindow = createBlock(MAX_SIZE, sbrk(MAX_SIZE));	//wholeWindow block must be free as it is not alocated, it is essentially a frame of reference
			printf("Created window of size: %d\n", wholeWindow->size);
			head = wholeWindow;  //sbrk returns the address of the previous break in the heap, before it increased it
			printf("Head address is: %p\n", head);
			hasMallocedBefore = true;
		}
		findAndAllocateMemoryOnHeap(sizePlusMetaNextPowerOfTwo, wholeWindow);
	
		printf("Head size is: %d\n", head->size);
		findBlock = head;
		struct block* tempBlock = head;
		int counter = 1;
		while(tempBlock->next != NULL){
			counter++;
			tempBlock = tempBlock->next;
		}
		printf("Size of memory tree is: %d\n", counter);
		while(findBlock->size != sizePlusMetaNextPowerOfTwo){
			if(findBlock->next != NULL){
				printf("Looking at size %d\n",findBlock->size);
				findBlock = findBlock->next;
			}
			else{
				printf("Couldn't find the block\n");
				break;
			}
		}
		printf("Finished custom mallocing\n");
		print_list();
	}
	
    return(findBlock->data);
}

void mergeWithBuddy(struct block* block){
	if(block < block->buddy){  //If we are looking at the left block in the buddy pair
		if(block->buddy->free == true){
			block->size = block->size * 2;
			block->free = true;
			block->next = block->buddy->next;
			block->buddy = block->merge_buddy[0];
			block->merge_buddy[0] = block->buddy->merge_buddy[0];
		}
	}
	
}

/** Mark a data block as free and merge free buddy blocks **/
void custom_free(void* ptr) {
    // TODO
	if(ptr != NULL){
		
	}
}

/** Change the memory allocation of the data to have at least the requested size **/
void* custom_realloc(void* ptr, size_t size) {
    // TODO
    return NULL;
}

/*------------------------------------*\
|            DEBUG FUNCTIONS           |
\*------------------------------------*/

/** Prints the metadata of a block **/
void print_block(struct block* b) {
    if(!b) {
        printf("NULL block\n");
    }
    else {
        int i = 0;
        printf("Strt = %p\n",b);
        printf("Size = %lu\n",b->size);
        printf("Free = %s\n",(b->free)?"true":"false");
        printf("Data = %p\n",b->data);
        printf("Next = %p\n",b->next);
        printf("Buddy = %p\n",b->buddy);    
        printf("Merge Buddies = "); 
        while(b->merge_buddy[i] && i < MAX_EXP) {
            printf("%p, ",b->merge_buddy[i]);
            i++;
        }
        printf("\n\n");
    }
}

/** Prints the metadata of all blocks **/
void print_list() {
    struct block* curr = head;
    printf("--HEAP--\n");
    if(!head) printf("EMPTY\n");
    while(curr) {
        print_block(curr);
        curr = curr->next;
    }
    printf("--END--\n");
}

/*---------------------------------------------------------------------Notes---------------------------------------------------------------------
https://stackoverflow.com/questions/14588767/where-in-memory-are-my-variables-stored-in-c
*/
