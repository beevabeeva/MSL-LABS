#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdarg.h>

// total number of lines, words, chars (if multiple files are input)
static int total_lines = 0, total_words = 0, total_chars = 0;
void wc(FILE *infile, char *inname);

int main(int argc, char *argv[]) {
    if(argc > 1) {
        
        // TODO: get the filename/s from argv, open each and pass it to wc
        for(int i = 1; i < argc; i++){
		FILE *inputFile;
		inputFile = fopen(argv[i], "r");
		wc(inputFile, argv[i]);
	}
        if(argc > 2) { // print totals for multiple files
            printf("%7d %7d %7d   %s\n",  total_lines, total_words, total_chars, "total");
        }
        
    } else {
        // TODO: no arguments, process input from stdin
	int lines = 0, words = 0, chars = 0;
	char inputFromKeyboard[256];
	fgets( inputFromKeyboard, 256, stdin );
	FILE * f = fopen("file.txt", "w");
	fprintf(f, inputFromKeyboard, '\n');
	fclose(f);
	FILE *g;
	g = fopen("file.txt", "r");
	wc(g, "");
    }
    
    return 0;
}

void wc(FILE *infile, char *inname) {
    int lines = 0, words = 0, chars = 0;
    int c;
    int c_past; 
    // TODO: read the file character by character and count the
    //       number of lines, words, and characters.
    if(infile){
	while((c = getc(infile)) != EOF){
		if((c == ' ') && (c_past != ' ') && (c_past != '\n')){
			chars = chars + 1;
			words = words + 1;
			c_past = c;
		}
		else if((c == ' ') && (c_past == ' ' || c_past == '\n')){
			chars = chars + 1;
			c_past = c;
		}
		else if((c == '\n') && (c_past != ' ') && (c_past != '\n')){
			chars = chars + 1;
			words = words + 1;
			lines = lines + 1;
			c_past = c;
		}
		else if((c == '\n') && (c_past == ' ' || c_past == '\n')){
			chars = chars + 1;
			lines = lines + 1;
			c_past = c;
		}
		else{
			chars = chars + 1;
			c_past = c;
		}
	}
    }
    total_lines += lines;
    total_words += words;
    total_chars += chars;
    printf("%7d %7d %7d   %s\n",  lines, words, chars, inname);
}
