#include "process.h"
#include "shell.h"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <termios.h>
#include <string.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "parse.h"

/**
 *  Executes the process p.
 *  If the shell is in interactive mode and the process is a foreground process,
 *  then p should take control of the terminal.
 *
 */
void launch_process(process *p) {
    /** TODO **/

	//The below completed assumes that our call will take care of all possible process events thus the process will be handled and compelted no matter what
	//p->completed = true; 

	setpgid(0,0);
	signal(SIGINT, SIG_DFL);
	//signal(SIGQUIT, SIG_DFL);
	//signal(SIGCHLD, SIG_DFL);
	signal(SIGTSTP,SIG_DFL);
	signal(SIGTTIN, SIG_DFL);
	signal(SIGTTOU, SIG_DFL);

	pid_t parentPID = getppid();

	tcgetattr (shell_terminal, &p->tmodes);

	tok_t* path = NULL;
	char* pathVariable = getenv("PATH");
	if(path == NULL){
		path = getToks(pathVariable);
	}

	p->stdout = isDirectTok(p->argv, ">");
	p->stdin = isDirectTok(p->argv, "<");
	
	/*if(strcmp(p->argv[sizeof(p->argv) - 1], "&")){
		printf("Enter into");
		tcsetpgrp(0, parentPID);
	}*/

	if((p->stdout == 0) && (p->stdin == 0)){
		execv(p->argv[0], p->argv);
		int indexToDrop = isDirectTok(p->argv, "&");
		for(unsigned int i = 0; i < sizeof(path); i++){
			//printf("Enter\n");
			if(indexToDrop != 0){
				p->argv[indexToDrop] = NULL;
			}
			char* finalProcess = malloc(strlen(path[i])+strlen(p->argv[0])+sizeof(char)+1);
			strcpy(finalProcess, path[i]);
			strcat(finalProcess, "/");
			strcat(finalProcess, p->argv[0]);
			execv(finalProcess, p->argv);
			free(finalProcess);
		}
	}


	if(p->stdout != 0){
		FILE* openFile = open((p->argv[p->stdout + 1]), O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
		//printf("Opened directory: %s\n", p->argv[p->stdout + 1]);
		dup2(openFile, 1);
		p->argv[p->stdout] = NULL;
		//printf(*p->argv);
		execv(p->argv[0], p->argv);
		for(unsigned int i = 0; i < sizeof(path); i++){
			//printf("Enter\n");
			char* finalProcess = malloc(strlen(path[i])+strlen(p->argv[0])+sizeof(char)+1);
			strcpy(finalProcess, path[i]);
			strcat(finalProcess, "/");
			strcat(finalProcess, p->argv[0]);
			execv(finalProcess, p->argv);
			free(finalProcess);
		}
		//close(openFile)###############################################################################################################
	}
	else if(p->stdin != 0){
		//printf("Receiving input...\n");
		FILE* openFile = open((p->argv[p->stdin + 1]), O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
		//printf("Opened directory: %s\n", p->argv[p->stdin + 1]);
		dup2(openFile, 0);
		p->argv[p->stdin] = NULL;
		//printf(p->argv[1]);
		execv(p->argv[0], p->argv);
		for(unsigned int i = 0; i < sizeof(path); i++){
			//printf("Enter\n");
			char* finalProcess = malloc(strlen(path[i])+strlen(p->argv[0])+sizeof(char)+1);
			strcpy(finalProcess, path[i]);
			strcat(finalProcess, "/");
			strcat(finalProcess, p->argv[0]);
			execv(finalProcess, p->argv);
			free(finalProcess);

		}
		//close(openFile)############################################################################################################
	}

	printf("Could not execute '%s' : No such file or directory", p->argv[0]);
	exit(0);
}

/**
 *  Put a process in the foreground. This function assumes that the shell
 *  is in interactive mode. If the cont argument is true, send the process
 *  group a SIGCONT signal to wake it up.
 *
 */
void put_process_in_foreground (process *p, int cont) {
    /** TODO **/

	/* Put the job into the foreground.*/
	p->background = false;
	//printf("Putting process: %d\n into foreground", p->pid);

	//tcsetpgrp(getpid(), p->pid);
	tcsetpgrp(shell_terminal, p->pid);
	if (cont){
		tcsetattr (shell_terminal, TCSADRAIN, &p->tmodes);
		if (kill (p->pid, SIGCONT) < 0){
			perror ("kill (SIGCONT)");
		}
    }

	//printf("%d\n", p->status);
	waitpid(p->pid, &p->status, WUNTRACED);
	//printf("%d\n", p->status);


	/* Put the shell back in the foreground.  */
	tcsetpgrp (shell_terminal, shell_pgid);
	//tcsetpgrp (shell_terminal, getpid());

	/* Restore the shell’s terminal modes.  */
	tcgetattr (shell_terminal, &p->tmodes);
	tcsetattr (shell_terminal, TCSADRAIN, &shell_tmodes);
	//tcsetattr(shell_terminal, TCSADRAIN, &p->tmodes);

	/*if(WIFEXITED(p->status) || WIFSIGNALED(p->status)){
		p->completed = true;
	}*/
}

/**
 *  Put a process in the background. If the cont argument is true, send
 *  the process group a SIGCONT signal to wake it up. 
 *
 */
void put_process_in_background (process *p, int cont) {
    /** TODO **/
	p->background = true;
	 if (cont){
	     if (kill (p->pid, SIGCONT) < 0){
		       perror ("kill (SIGCONT)");
		 }
	}
}

/**
 *  Prints the list of processes.
 *
 */
void print_process_list(void) {
    process* curr = first_process;
    while(curr) {
        //if(!curr->completed) {
            printf("\n");
            printf("PID: %d\n",curr->pid);
            printf("Name: %s\n",curr->argv[0]);
            printf("Status: %d\n",curr->status);
            printf("Completed: %s\n",(curr->completed)?"true":"false");
            printf("Stopped: %s\n",(curr->stopped)?"true":"false");
            printf("Background: %s\n",(curr->background)?"true":"false");
            printf("Prev: %lx\n",(unsigned long)curr->prev);
            printf("Next: %lx\n",(unsigned long)curr->next);
        //}
        curr=curr->next;
    }
}
