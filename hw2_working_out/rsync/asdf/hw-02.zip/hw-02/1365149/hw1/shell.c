#define _POSIX_SOURCE

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdbool.h>

#define INPUT_STRING_SIZE 80
#define CNORMAL "\x1B[0m"
#define CYELLOW "\x1B[33m"

#include "io.h"
#include "parse.h"
#include "process.h"
#include "shell.h"
#include <wordexp.h>

int cmd_help(tok_t arg[]);
int cmd_quit(tok_t arg[]);
int cmd_pwd(tok_t arg[]);
int cmd_cd(tok_t arg[]);
int cmd_wait(tok_t arg[]);
int cmd_fg(tok_t arg[]);
char* prevDir;

//tok_t* p = NULL;
/** 
 *  Built-In Command Lookup Table Structures 
 */
typedef int cmd_fun_t (tok_t args[]); // cmd functions take token array and return int
typedef struct fun_desc {
    cmd_fun_t *fun;		      //Actual function. Made by the above typedef cmd_fun_t
    char *cmd;
    char *doc;
} fun_desc_t;
/** TODO: add more commands (pwd etc.) to this lookup table! */
fun_desc_t cmd_table[] = {
    {cmd_help, "help", "show this help menu"},
    {cmd_quit, "quit", "quit the command shell"},
	{cmd_pwd, "pwd", "prints the current working directory"},
	{cmd_cd, "cd", "changed the working directory"},
	{cmd_wait, "wait", "makes parent process wait until all background jobs have terminated before returning"},
	{cmd_fg, "fg", "brings specified process to foreground"},
};


/**
 *  Determine whether cmd is a built-in shell command
 *
 */
int lookup(char cmd[]) {
    unsigned int i;
    for (i=0; i < (sizeof(cmd_table)/sizeof(fun_desc_t)); i++) {	//size of array cmd_table divided by size of fun_desc_t the array elements = last index of array 
        if (cmd && (strcmp(cmd_table[i].cmd, cmd) == 0)) return i;      //compares cmd entered to see if it is known command (cmd_table[] holds all possible cmd's
    }
    return -1;								//If no command is found?
}

/**
 *  Print the help table (cmd_table) for built-in shell commands
 *
 */
int cmd_help(tok_t arg[]) {
    unsigned int i;
    for (i = 0; i < (sizeof(cmd_table)/sizeof(fun_desc_t)); i++) {	//size of array cmd_table divided by size of fun_desc_t the array elements = last index of array
        printf("%s - %s\n",cmd_table[i].cmd, cmd_table[i].doc);		//prints command string and then the documentation for that command
    }
    return 1;
}

/**
 *  Quit the terminal
 *
 */
int cmd_quit(tok_t arg[]) {
    printf("Bye\n");
    exit(0);
    return 1;
}

/**
 *  Print the current working directory
 *
 */
int cmd_pwd(tok_t arg[]){
	char directory[100];
	if(getcwd(directory, sizeof(directory)) != NULL){
		printf("%s\n", directory);
	}
	else{
		perror("getcwd() error");
	}
	return(1);
}

/**
 * Changes to the specified dirctory
 *
 */
int cmd_cd(tok_t arg[]){
	if(sizeof(arg[0]) != 0){
		if(arg[0][0] != '-'){
	    	char* previousDir = malloc(sizeof(char) * 100);
			getcwd(previousDir,(sizeof(char)*100));
			prevDir = previousDir;
			//free(previousDir);						//**Memory leak**//
		}
		
		if((arg[0][0] != '~') && (arg[0][0] != '-')){
			chdir(arg[0]);
		}
		else if(arg[0][0] == '~'){
			char* arguments = (arg[0] + sizeof(char));
			char* home = getenv("HOME");	
			char* finalDir = malloc(strlen(home)+strlen(arguments)+1);
			strcpy(finalDir, home);
			strcat(finalDir, arguments);
			chdir(finalDir);
		}
		else if(arg[0][0] == '-'){
			char* previousDir = malloc(sizeof(char) * 100);
			getcwd(previousDir, (sizeof(char)*100));
			chdir(prevDir);
			prevDir = previousDir;
		}

		

//*************Come back and try this implementation**************//
		/*printf("%s", "check");
		char* finalDir = malloc(sizeof(char)*100);
		//char finalDir[1000];
		for(int i = 0; i < sizeof(arg[0]); i++){
			printf("%s", arg[0][i]);
			if(arg[0][i] != '~'){
				strcat(finalDir, arg[0][i]);
			}
			else{
				strcat(finalDir, getenv("HOME"));
			}
		}*/
	}
	return(1);
}


/**
 *
 *
 */
int cmd_wait(tok_t arg[]){
	//waitpid(-1, NULL, 0);
	//wait(NULL);
	//pid_t pid;
	/*while(true){
		if(pid = waitpid(-1, NULL, 0)){
			wait(NULL);
		}
		else{
			break;
		}
	}*/
	/*pid = waitpid(-1, NULL, WUNTRACED);
	while(true){
		if(pid == -1){
			break;
		}
		printf("Waiting...\n");
		cmd_wait(arg);
	}*/
	process* processSearcher = first_process;
	while(processSearcher->next != NULL){
		if(processSearcher->stopped != true){
			waitpid(processSearcher->pid, NULL, 0);
		}
		processSearcher = processSearcher->next;
	}
	if(processSearcher->stopped != true){
		waitpid(processSearcher->pid, NULL, 0);
	}

	return(1);
}


int cmd_fg(tok_t arg[]){
	if(arg[0] != NULL){
		process* searchingPointer = first_process;
		printf("Searching at: %d\n", searchingPointer->pid);
		while((searchingPointer->pid != arg[0][0]) && (searchingPointer->next != NULL)){
			searchingPointer = searchingPointer->next;
		//	printf("Searchinf at: %d\n", searchingPointer->pid);
		}
		put_process_in_foreground(searchingPointer, searchingPointer->stopped);
		if(WIFEXITED(searchingPointer->status)){
			searchingPointer->completed = true;
		}
		else if(WIFSTOPPED(searchingPointer->status)){
			searchingPointer->stopped = true;
			searchingPointer->background = true;
		}
		if(WIFCONTINUED(searchingPointer->status)){
			searchingPointer->stopped = false;
		}
	}
	else{
		process* searchingPointer = first_process;
		while(searchingPointer->next != NULL){
			searchingPointer = searchingPointer->next;
		}
		//printf("Ok");
		put_process_in_foreground(searchingPointer, searchingPointer->stopped);
		if(WIFEXITED(searchingPointer->status)){
			searchingPointer->completed = true;
		}
		else if(WIFSTOPPED(searchingPointer->status)){
			searchingPointer->stopped = true;
			searchingPointer->background = true;
		}
		if(WIFCONTINUED(searchingPointer->status)){
			searchingPointer->stopped = false;
		}
	}
	return(1);
}

/**
 *  Initialise the shell
 *
 */
void init_shell() {
    // Check if we are running interactively
    shell_terminal = STDIN_FILENO;

    // Note that we cannot take control of the terminal if the shell is not interactive
    shell_is_interactive = isatty(shell_terminal);

    if( shell_is_interactive ) {

        // force into foreground
        while(tcgetpgrp (shell_terminal) != (shell_pgid = getpgrp()))
            kill( - shell_pgid, SIGTTIN);

        shell_pgid = getpid();
        // Put shell in its own process group
        if(setpgid(shell_pgid, shell_pgid) < 0){
            perror("Couldn't put the shell in its own process group");
            exit(1);
        }

        // Take control of the terminal
        tcsetpgrp(shell_terminal, shell_pgid);
        tcgetattr(shell_terminal, &shell_tmodes);
    }

    /** TODO */
    // ignore signals
	signal(SIGINT, SIG_IGN);
	signal(SIGTSTP, SIG_IGN);
	signal(SIGTTIN, SIG_IGN);
	signal(SIGTTOU, SIG_IGN);

}

/**
 * Add a process to our process list
 *
 */
void add_process(process* p)
{
    /** TODO **/
	//printf("Enter add_process\n");
	if(first_process != NULL){
		process* currProcess = first_process;
		int index = 0;
		//printf("%p\n", currProcess->next);
		//printf("%p\n", currProcess);
		while(currProcess->next != NULL){
			//printf("%d\n", index);
			currProcess = currProcess->next;
			//printf("Moved to next");
			index++;
		}
	
		//printf("OK Lego");
		currProcess->next = p;
		p->prev = currProcess;
		//printf("Exit add_process\n");
	}
}

/**
 * Creates a process given the tokens parsed from stdin
 *
 */
process* create_process(tok_t* tokens)
{
    /** TODO **/
    //return NULL;
	//printf("Enter create_process");
	process* newProcess = malloc(sizeof(struct process));
	
	newProcess->argv = tokens;
	newProcess->argc = sizeof(tokens);
	//newProcess->pid = getpid();
	newProcess->completed  = false;
	newProcess->stopped = false;
	newProcess->background = false;
	newProcess->next = NULL;
	newProcess->prev = NULL;
	tcgetattr (shell_terminal, &newProcess->tmodes);
	return(newProcess);
}



/**
 * Main shell loop
 *
 */
int shell (int argc, char *argv[]) {
    int lineNum = 0;
    pid_t pid = getpid();	// get current process's PID
    pid_t ppid = getppid();	// get parent's PID
    pid_t cpid;             // use this to store a child PID

    char *s = malloc(INPUT_STRING_SIZE+1); // user input string
    tok_t *t;			                   // tokens parsed from input
    // if you look in parse.h, you'll see that tokens are just C-style strings (char*)

    // perform some initialisation
    init_shell();

    fprintf(stdout, "%s running as PID %d under %d\n",argv[0],pid,ppid);
	char path[100];
    /** TODO: replace "TODO" with the current working directory */
    fprintf(stdout, CYELLOW "\n%d %s# " CNORMAL, lineNum, getcwd(path, sizeof(path)));
    
    // Read input from user, tokenize it, and perform commands
    while ( ( s = freadln(stdin) ) ) { 
    
        t = getToks(s);            // break the line into tokens
        int fundex = lookup(t[0]); 
        if( fundex >= 0 ) {	   
            cmd_table[fundex].fun(&t[1]); // execute built-in command
        } else {
			//print_process_list();
			if(first_process == NULL){
				//printf("Should run once");
			}
            /** TODO: replace this statement to call a function that runs executables */
            //fprintf(stdout, "This shell only supports built-in functions. Replace this to run programs as commands.\n");
			//printf("Size of t: %d\n", sizeof(t));
			process* childProcess = create_process(t);
			if(first_process == NULL){
				first_process = childProcess;
				first_process->next = NULL;
			}
			else{
				add_process(childProcess);
			}

			cpid = fork();
			if(cpid == 0){			//If we are talking to the child process
				//int currentPID = getpid();
				//printf("%d\n", currentPID);
				//setpgid(currentPID,currentPID);
				//printf("Before it \n");
				launch_process(childProcess);
				//printf("After it\n");
			}
			else{
				childProcess->pid = cpid;
				int indexOfAmp = isDirectTok(childProcess->argv, "&");
				if(indexOfAmp == 0){
					tcsetpgrp(0, cpid);
					//waitpid(-1, NULL, 0);
					//waitpid(cpid, childProcess->status, WUNTRACED);
					waitpid(cpid, childProcess->status, WUNTRACED);
					if(WIFCONTINUED(childProcess->status)){
						childProcess->stopped = false;
					}
					else{
						childProcess->stopped = true;
						childProcess->background = true;
					}
					if(WIFEXITED(childProcess->status) || WIFSIGNALED(childProcess->status)){
						childProcess->completed = true;
					}
				}
				else{
					//childProcess->background = true;
					put_process_in_background(childProcess, childProcess->stopped);
				}
				/*if(childProcess->background == true){
					printf("Yes its true");
				}*/
				//wait(&exit);
				//printf("Inside the parent\n");
				//waitpid(cpid, &childProcess, WUNTRACED);
				//waitpid(-1, NULL, 0);
				tcsetpgrp(0, getpid());
				//printf("Should come last\n");
			}
        }
		//print_process_list();
        lineNum++;
        /** TODO: replace "TODO" with the current working directory */
        fprintf(stdout, CYELLOW "\n%d %s# " CNORMAL, lineNum, getcwd(path, sizeof(path)));
    }
    return 0;
}
